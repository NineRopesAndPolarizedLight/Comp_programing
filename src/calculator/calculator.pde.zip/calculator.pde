// julian bryson | sept 14 2026 | calculator
String displayVal;
float l,r,op;
boolean left;
Button [] numButtons = new Button[15];
Button [] opButtons = new Button[12];

void setup(){
  size(195,285);
  displayVal = "0.0";
  l = 0.0;
  r = 0.0;
  numButtons[1] = new Button(15,75,30,30);
  numButtons[2] = new Button(60,75,30,30);
  numButtons[3] = new Button(105,75,30,30);
  numButtons[4] = new Button(15,120,30,30);
  numButtons[5] = new Button(60,120,30,30);
  numButtons[6] = new Button(105,120,30,30);
  numButtons[7] = new Button(15,165,30);
  numButtons[8] = new Button(60,165,30,30);
  numButtons[9] = new Button(105,165,30,30);
  numButtons[0] = new Button(15,210,30,30);
}

void draw(){
background(75);
drawDisplay();
for(int i = 0; i<numButtons.length; i++) {
  numButtons[i].display();
  numButtons[i].mouseOver(mouseX,mouseY);
}
for(int i = 0; i<numButtons.length; i++) {
  numButtons[i].display();
  numButtons[i].mouseOver(mouseX,mouseY);
}

void updateDisplay(){
rectMode(CENTER);
fill(127);
rect(width/2,25,110,40);
fill(0);
text(displayVal,width-25,30);

}

void mouseReleased(){
  for(int i = 0; i< numButtons.length; i++) {
  if(numButtons[i].hover == true){
    displayVal = str(numButtons[i].val);
}
  }
for(int i = 0; i < opButtons.length; i++){
  
}
  }
}
